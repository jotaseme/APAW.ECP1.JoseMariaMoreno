package es.upm.miw.pd.factoryMethod.naturalNumber.solution;

public abstract class NaturalNumberCreator {
	public abstract NaturalNumber createNaturalNumber(int value);
}
