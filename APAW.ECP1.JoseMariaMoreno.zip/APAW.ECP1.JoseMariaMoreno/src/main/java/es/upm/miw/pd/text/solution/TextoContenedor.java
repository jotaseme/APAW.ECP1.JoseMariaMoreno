package es.upm.miw.pd.text.solution;

public abstract class TextoContenedor extends Texto {
	
	public abstract void delete(Texto texto);

}
