package es.upm.miw.pd.state.connection.solution;

public enum Estado {
    CERRADO, PARADO, PREPARADO, ESPERANDO;
}
