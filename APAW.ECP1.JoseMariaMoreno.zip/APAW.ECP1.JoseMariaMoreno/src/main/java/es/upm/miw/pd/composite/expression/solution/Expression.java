package es.upm.miw.pd.composite.expression.solution;

public abstract class Expression {

	public abstract int operar();

	public abstract String toString();

}
