package es.upm.miw.pd.command.calculator.solution;


public interface Comando {  
	public void execute();
	public String name();
}
